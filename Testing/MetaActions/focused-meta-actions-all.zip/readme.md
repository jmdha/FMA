# Meta Actions

These are meta actions generated with no post-usefulness check.

Do note: Childsnack and Woodworking has no meta actions.
