# Meta Actions

These are meta actions generated with no post-usefulness check.
These are more or less just made so we dont have to rerun the generation and refinement process, each time we wanted to try a new post-usefulness check.
Do note, if you are going to use these, you can use the "Manual" meta action generator option, and give a path to this folder.
