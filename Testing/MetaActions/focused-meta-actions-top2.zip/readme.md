# Meta Actions

These meta actions are the ones used to for results.

They are generated with the PlanLengthTop2 usefulness check.

Do note: Childsnack, Woodworking and Parking has no meta actions.

## Parameters
It has been run with a usefulness time limit of 5 min.
```
--post-usefulness-strategy ReducesPlanLengthTop2
--usefulness-time-limit 300
```
